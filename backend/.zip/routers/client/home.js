const homeController = require("../../controllers/client/home.js");
const express = require("express");
const router = express.Router();

router