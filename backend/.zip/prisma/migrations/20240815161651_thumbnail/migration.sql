-- AlterTable
ALTER TABLE "products" ADD COLUMN     "thumbnail" VARCHAR(255);
