interface Categories {
  id: number;
  name: string;
  slug: string;
  image_url: string;
}

export type { Categories };
