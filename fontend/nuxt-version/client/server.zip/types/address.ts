interface Address {
  id: number;
  name: string;
  address: string;
  phone_number: string;
}

export type { Address };
