import * as vt from "vue-toastification";

export const eToast = vt.useToast;
