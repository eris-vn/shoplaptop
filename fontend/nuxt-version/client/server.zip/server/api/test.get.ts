export default defineEventHandler(async (event) => {
  return `Hello world!`;
});
